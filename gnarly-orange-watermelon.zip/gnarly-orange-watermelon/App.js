import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';

// Função para criar os tempos de contagem para cada tipo de senha
const getSenhaTime = (priority) => {
  switch (priority) {
    case 'Alta Prioridade':
      return 30; // 30 segundos
    case 'Prioritária':
      return 45; // 45 segundos
    default:
      return 90; // 90 segundos
  }
};

const App = () => {
  const [senhas, setSenhas] = useState([
    { id: 1, numero: 'A001', prioridade: 'Normal', tempo: getSenhaTime('Normal') },
    { id: 2, numero: 'P001', prioridade: 'Prioritária', tempo: getSenhaTime('Prioritária') },
    { id: 3, numero: 'AP001', prioridade: 'Alta Prioridade', tempo: getSenhaTime('Alta Prioridade') },
  ]);
  const [senhasAtivas, setSenhasAtivas] = useState([]); // Lista de senhas ativas

  // Chamar uma nova senha automaticamente
  const chamarSenhaAutomaticamente = () => {
    if (senhas.length === 0) return;
    const proximaSenha = senhas[0]; // Pegando a próxima senha para chamar
    setSenhasAtivas((prev) => [...prev, proximaSenha]); // Adiciona a senha à lista de ativas
    setSenhas((prev) => prev.filter((senha) => senha.id !== proximaSenha.id)); // Remove da lista original
  };

  // Configura o intervalo para chamar senhas automaticamente
  useEffect(() => {
    const timer = setInterval(() => {
      if (senhas.length > 0) {
        const proximaSenha = senhas[0];
        chamarSenhaAutomaticamente();
      }
    }, 1000); // Verifica a cada segundo

    return () => clearInterval(timer); // Limpa o intervalo quando o componente for desmontado
  }, [senhas]);

  useEffect(() => {
    // Decrementa o tempo das senhas ativas
    const timer = setInterval(() => {
      setSenhasAtivas((prev) => {
        return prev.map((senha) => {
          if (senha.tempo > 0) {
            return { ...senha, tempo: senha.tempo - 1 }; // Reduz o tempo
          } else {
            // Quando o tempo chega a 0, remove a senha da lista ativa
            return null;
          }
        }).filter(Boolean); // Filtra as senhas nulas (removidas)
      });
    }, 1000); // Reduz o tempo de cada senha ativa a cada segundo

    return () => clearInterval(timer); // Limpa o intervalo
  }, []);

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes < 10 ? '0' : ''}${minutes}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sistema de Chamada de Senhas</Text>

      {senhasAtivas.length > 0 ? (
        <View style={styles.senhasAtivasContainer}>
          {senhasAtivas.map((senha) => (
            <View
              key={senha.id}
              style={[styles.senhaContainer, { borderColor: senha.prioridade === 'Alta Prioridade' ? '#e74c3c' : senha.prioridade === 'Prioritária' ? '#f39c12' : '#2ecc71' }]}>
              <Text style={styles.senhaText}>
                Senha: {senha.numero} ({senha.prioridade})
              </Text>
              <Text style={styles.timerText}>
                {formatTime(senha.tempo)} restantes
              </Text>
            </View>
          ))}
        </View>
      ) : (
        <Text style={styles.senhaText}>Aguardando chamada...</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 30,
  },
  senhasAtivasContainer: {
    marginBottom: 20,
    width: '100%',
  },
  senhaContainer: {
    marginBottom: 15,
    alignItems: 'center',
    padding: 20,
    borderWidth: 3,
    borderRadius: 10,
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 5,
  },
  senhaText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
  },
  timerText: {
    fontSize: 18,
    color: '#e74c3c',
    marginTop: 10,
  },
});

export default App;